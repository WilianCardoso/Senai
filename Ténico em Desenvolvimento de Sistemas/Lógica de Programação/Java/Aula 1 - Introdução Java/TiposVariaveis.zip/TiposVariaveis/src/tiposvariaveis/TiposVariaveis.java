/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tiposvariaveis;

/**
 *
 * @author wilian_g_cardoso
 */
public class TiposVariaveis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           //tipos primitivos
           byte a = 2; // -128 a 127 = 1 bytes
           short b = 2; // -32768 a 32767 = 2 bytes
           int c = 2; // -2146483648 a 2146483647 = bytes
           long d = 2; // vai de 9 e uma porrada de números negativos e uma cacetada
           boolean e = false; // 1 bit
           char f = 'a'; // 2 bytes
           float g = 314; // 4 bytes
           double h = 3.14; // 8 bytes
           
           
           
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author wilian_g_cardoso
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pilha p1 = new Pilha(50);
        p1.empilha(50);
        p1.empilha(70);
        p1.empilha(90);
        p1.empilha(10);
        p1.print();
        p1.desempilha();
        p1.print();
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author wilian_g_cardoso
 */
public class calculadora {

    public static void adicao(int nm1, int nm2) {
        int result;

        result = nm1 + nm2;
        System.out.println("O reslultado da soma foi: " + result);
    }

    public static void subtracao(int nm1, int nm2) {
        int result;
        result = nm1 - nm2;
        System.out.println("O reslultado da subtracao foi: " + result);
    }

    public static void multiplicacao(int nm1, int nm2) {
        int result;
        result = nm1 * nm2;
        System.out.println("O reslultado da multiplicacao foi: " + result);
    }

    public static void divisao(int nm1, int nm2) {
        int result;
        result = nm1 / nm2;
        System.out.println("O reslultado da divisao foi: " + result);
    }
}
